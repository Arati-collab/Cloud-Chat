import { useEffect, useState } from "react";

import { sendMessage, listenMessages } from "./lib/chat";

function App() {
  const [messages, setMessages] = useState([]);
  const [text, setText] = useState("");

  const roomId = "global-room";

  useEffect(() => {
    const unsub = listenMessages(roomId, setMessages);

    return () => {
      if (unsub) unsub();
    };
  }, []);

  const handleSend = async () => {
    if (!text) return;

    await sendMessage(roomId, "user1", text);

    setText("");
  };

  return (
    <div style={{ padding: 20 }}>
      <h1>💬 Cloud Chat</h1>

      <div
        style={{
          border: "1px solid gray",
          height: 300,
          overflowY: "scroll",
          padding: 10,
          marginBottom: 10
        }}
      >
        {messages.map((msg) => (
          <div key={msg.id}>
            <b>{msg.senderId}:</b> {msg.text}
          </div>
        ))}
      </div>

      <input
        value={text}
        onChange={(e) => setText(e.target.value)}
        placeholder="Type message..."
      />

      <button onClick={handleSend}>Send</button>
    </div>
  );
}

export default App;
